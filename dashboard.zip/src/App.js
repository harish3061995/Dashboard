import logo from "./logo.svg";
import "./App.css";
import { useDispatch, useSelector } from "react-redux";
import { decrement, increment } from "./app/Slice";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import About from "./pages/About";
import Layout from "./pages/Layout";

function App() {
  const count = useSelector((state) => state.CommonSlice.value);
  const dispatch = useDispatch();
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/*" element={<About />} />
          </Route>
        </Routes>
      </BrowserRouter>

      {/* <button onClick={() => dispatch(increment())}>increment</button> */}
    </div>
  );
}

export default App;

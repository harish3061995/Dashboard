import React, { MouseEvent, useRef } from "react";

import BarChart from "../components/Chart";
import MixedChart from "../components/Chart";
import legend from "../assets/img/legend.png";
import NewAssesment from "../components/NewAssesment";
import TodayInterviewMeeting from "../components/TodayInterviewMeeting";
import PostedJobs from "../components/PostedJobs";
import CandidateStatus from "../components/CandidateStatus";
import DateRangePickerComponent from "../components/Calendar";
import Upcomings from "../components/Upcomings";
import HiringCandidates from "../components/HiringCandidates";
import Activity from "../components/Activity";

function Home(props) {
  return (
    <div className="px-3">
      <h2 className="font-semibold text-2xl mb-3">HR Employee</h2>
      <p className="text-lg text-[#3E3E3E] mb-8">
        Enjoy your selecting potential candidates Tracking and Management
        System.
      </p>

      <div>
        <div className="flex flex-row space-x-5">
          <div className="w-1/2 bg-white rounded-lg shadow-[4px_4px_25px_0px_#00000026]">
            <h5 className="text-xl font-semibold flex flex-row border-b-2 px-3 py-3 mb-4 items-center">
              <span>Application’s Info</span>
              <img src={legend} alt="legend" className=" ml-10 w-auto h-5" />
            </h5>
            <MixedChart />
          </div>
          <div className="w-1/2 p-7 gradient rounded-lg  shadow-[4px_4px_25px_0px_#00000026] bg-custom-gradient flex">
            <NewAssesment />
          </div>
        </div>
      </div>
      {/* 10  section  */}
      <div className="flex flex-row space-x-5 mt-7">
        <div className="w-9/12 space-y-10 mb-10">
          <TodayInterviewMeeting />
          <PostedJobs />
          <CandidateStatus />
        </div>
        {/* 2 section */}
        <div className="w-3/12">
          <DateRangePickerComponent />
          <Upcomings />
          <Activity />
          <HiringCandidates />
        </div>
      </div>
    </div>
  );
}

export default Home;

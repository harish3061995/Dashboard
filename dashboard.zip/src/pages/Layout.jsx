import React from "react";
import { Link, Outlet } from "react-router-dom";
import Navbar from "../components/Navbar";
import SideBar from "../components/SideBar";

function Layout() {
  return (
    <div>
      <header>
        <Navbar />
      </header>
      <main>
        <div className="flex mt-10">
          <div className="w-[100px]">
            <SideBar />
          </div>
          <div className="w-[calc(100%_-_100px)] px-4">
            <Outlet />
          </div>
        </div>
      </main>
    </div>
  );
}

export default Layout;

import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  barData: [
    2100, 2900, 3100, 2700, 3700, 1900, 3200, 2600, 4110, 600, 3000, 3900,
  ],
  linedata: [
    1800, 800, 2000, 2700, 3000, 1100, 400, 2500, 3200, 1800, 500, 2000,
  ],
  Candidatedata: [
    {
      imgSrc: "male",
      name: "John Smith",
      position: "Senior Python Developer",
      date: "19th Feb 2024",
      time: "10.30 A.M",
      levels: [
        { level: "1st Level", score: "7/10", interviewer: "Stella" },
        { level: "2nd Level", score: "6/10", interviewer: "Smith" },
        { level: "3rd Level", score: "Waiting", interviewer: "Stephan" },
        { level: "Meet Via", score: "G-meet", interviewer: "johanson" },
      ],
    },
    {
      imgSrc: "female",
      name: "Maria",
      position: "Senior Python Developer",
      date: "19th Feb 2024",
      time: "10.30 A.M",
      levels: [
        { level: "1st Level", score: "7/10", interviewer: "Stella" },
        { level: "2nd Level", score: "6/10", interviewer: "Smith" },
        { level: "3rd Level", score: "Waiting", interviewer: "Stephan" },
        { level: "Meet Via", score: "G-meet", interviewer: "johanson" },
      ],
    },
  ],
};

export const CommonSlice = createSlice({
  name: "counter",
  initialState,
  reducers: {},
});

// Action creators are generated for each case reducer function
export const { increment, decrement, incrementByAmount } = CommonSlice.actions;

export default CommonSlice.reducer;

import React, { useState } from "react";
import { FaSearch } from "react-icons/fa";
import {
  IoCloseCircleOutline,
  IoEyeOutline,
  IoFilterOutline,
} from "react-icons/io5";
import { useSelector } from "react-redux";

function CandidateStatus(props) {
  return (
    <div className="flex flex-row space-x-5 ">
      <div className="w-full bg-white rounded-lg shadow-[4px_4px_25px_0px_#00000026]">
        <div className=" flex justify-between text-xl font-semibold  flex-col px-3 pt-3 mb-4 items-center">
          <div className="w-full flex justify-between">
            <div className="w-full">
              <span> PostedJobs</span> &nbsp; &nbsp; &nbsp;
              <a
                href="javascript:void(0)"
                className="text-blue-500 text-base underline leading-6"
              >
                View All
              </a>
            </div>
            <div className="w-full flex flex-row justify-end">
              <div className="relative mr-4">
                <input
                  type="text"
                  placeholder="Search..."
                  className="pl-4 pr-10 max-w-52 py-2 rounded-sm drop-shadow-md focus:outline-none text-base"
                />
                <FaSearch className="absolute right-3 top-3 text-gray-400" />
              </div>
              <div className="flex relative rounded-sm shadow-md py-1 px-3 items-center justify-center">
                <IoFilterOutline className="text-blue-500" /> &nbsp;&nbsp;&nbsp;
                <span className="text-base">Filters</span>
              </div>
            </div>
          </div>
        </div>
        <div className=" px-7 py-9 flex ">
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm font-light">
              <thead className="border-b font-medium dark:border-neutral-500 bg-slate-100">
                <tr>
                  <th scope="col" className="px-4 py-3 font-semibold ">
                    Job ID
                  </th>
                  <th scope="col" className="px-4 py-3 font-semibold ">
                    Name
                  </th>
                  <th scope="col" className="px-4 py-3 font-semibold ">
                    Position
                  </th>
                  <th scope="col" className="px-4 py-3 font-semibold ">
                    1st Level
                  </th>
                  <th scope="col" className="px-4 py-3 font-semibold ">
                    2nd Level
                  </th>
                  <th scope="col" className="px-4 py-3 font-semibold ">
                    3rd Level
                  </th>
                  <th scope="col" className="px-4 py-3 font-semibold ">
                    4th Level
                  </th>
                  <th scope="col" className="px-4 py-3 font-semibold ">
                    Total Marks
                  </th>
                  <th scope="col" className="px-4 py-3 font-semibold ">
                    Status
                  </th>
                  <th scope="col" className="px-4 py-3 font-semibold ">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b dark:border-neutral-500">
                  <td className="whitespace-nowrap px-6 py-4 font-medium">
                    #001
                  </td>
                  <td className="whitespace-nowrap px-6 py-4">John Doe</td>
                  <td className="whitespace-nowrap px-6 py-4">Designer</td>
                  <td className="whitespace-nowrap px-6 py-4">6/10</td>
                  <td className="whitespace-nowrap px-6 py-4">7/10</td>
                  <td className="whitespace-nowrap px-6 py-4">3/10</td>
                  <td className="whitespace-nowrap px-6 py-4">. . .</td>
                  <td className="whitespace-nowrap px-6 py-4">. . .</td>
                  <td className="whitespace-nowrap px-6 py-4">
                    <span className="px-2 py-1 text-yellow-600 bg-yellow-100 rounded">
                      Active
                    </span>
                  </td>
                  <td className="whitespace-nowrap px-6 py-4">
                    <IoEyeOutline />
                  </td>
                </tr>
                <tr className="border-b dark:border-neutral-500">
                  <td className="whitespace-nowrap px-6 py-4 font-medium">
                    #002
                  </td>
                  <td className="whitespace-nowrap px-6 py-4">John Smith</td>
                  <td className="whitespace-nowrap px-6 py-4">Developer</td>
                  <td className="whitespace-nowrap px-6 py-4">6/10</td>
                  <td className="whitespace-nowrap px-6 py-4">7/10</td>
                  <td className="whitespace-nowrap px-6 py-4">3/10</td>
                  <td className="whitespace-nowrap px-6 py-4">8/10</td>
                  <td className="whitespace-nowrap px-6 py-4">24/40</td>
                  <td className="whitespace-nowrap px-6 py-4">
                    <span className="px-2 py-1 text-green-600 bg-green-100 rounded">
                      Hired
                    </span>
                  </td>
                  <td className="whitespace-nowrap px-6 py-4">
                    <IoEyeOutline />
                  </td>
                </tr>
                <tr className="border-b dark:border-neutral-500">
                  <td className="whitespace-nowrap px-6 py-4 font-medium">
                    #003
                  </td>
                  <td className="whitespace-nowrap px-6 py-4">Stella</td>
                  <td className="whitespace-nowrap px-6 py-4">
                    Junior Designer
                  </td>
                  <td className="whitespace-nowrap px-6 py-4">2/10</td>
                  <td className="whitespace-nowrap px-6 py-4">3/10</td>
                  <td className="whitespace-nowrap px-6 py-4">
                    <IoCloseCircleOutline className="text-red-400" />
                  </td>
                  <td className="whitespace-nowrap px-6 py-4">
                    <IoCloseCircleOutline className="text-red-400" />{" "}
                  </td>
                  <td className="whitespace-nowrap px-6 py-4">5/40</td>
                  <td className="whitespace-nowrap px-6 py-4">
                    <span className="px-2 py-1 text-red-600 bg-red-100 rounded">
                      Rejected
                    </span>
                  </td>
                  <td className="whitespace-nowrap px-6 py-4">
                    <IoEyeOutline />
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CandidateStatus;

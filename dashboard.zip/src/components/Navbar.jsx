import React, { useState } from "react";
import {
  FaSearch,
  FaBell,
  FaEnvelope,
  FaCog,
  FaUser,
  FaBars,
} from "react-icons/fa";
import logo from "../assets/img/logo.png";
import user from "../assets/img/user.png";
import { GoSun } from "react-icons/go";
import { LiaFileUploadSolid } from "react-icons/lia";
import {
  IoChatbubbleEllipsesOutline,
  IoSettingsOutline,
} from "react-icons/io5";
import { MdOutlineNotificationImportant } from "react-icons/md";

const Navbar = () => {
  const [menuActive, setMenuActive] = useState(false);

  return (
    <nav className="p-4 shadow-lg flex justify-between items-center bg-white">
      <div className="flex items-center space-x-10">
        <div className=" font-bold text-xl">
          <img src={logo} alt="Logo" className="h-16 w-auto" />
        </div>
        <div className=" relative">
          <input
            type="text"
            placeholder="Search..."
            className="pl-4 pr-10 py-2 rounded-sm drop-shadow-md focus:outline-none"
          />
          <FaSearch className="absolute right-3 top-3 text-gray-400" />
        </div>
      </div>
      <div className="flex items-center space-x-16 hidden md:flex">
        <GoSun className=" text-xl cursor-pointer" />
        <LiaFileUploadSolid className=" text-xl cursor-pointer" />
        <IoChatbubbleEllipsesOutline className=" text-xl cursor-pointer" />
        <MdOutlineNotificationImportant className=" text-xl cursor-pointer" />
        <IoSettingsOutline className=" text-xl cursor-pointer" />

        <div className="relative group">
          <img src={user} alt="user" className="" />
          <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-2 hidden group-hover:block">
            <a
              href="#"
              className="block px-4 py-2 text-gray-800 hover:bg-gray-200"
            >
              Profile
            </a>
            <a
              href="#"
              className="block px-4 py-2 text-gray-800 hover:bg-gray-200"
            >
              Settings
            </a>
            <a
              href="#"
              className="block px-4 py-2 text-gray-800 hover:bg-gray-200"
            >
              Logout
            </a>
          </div>
        </div>
      </div>
      <div className="md:hidden" onClick={() => setMenuActive(!menuActive)}>
        <FaBars className=" text-xl cursor-pointer" />
      </div>
      <div
        className={`flex flex-col items-center space-y-2 absolute top-16 shadow-md p-10 left-0 w-full bg-white md:hidden ${
          menuActive ? "block" : "hidden"
        }`}
      >
        <GoSun className=" text-xl cursor-pointer" />
        <LiaFileUploadSolid className=" text-xl cursor-pointer" />
        <IoChatbubbleEllipsesOutline className=" text-xl cursor-pointer" />
        <MdOutlineNotificationImportant className=" text-xl cursor-pointer" />
        <IoSettingsOutline className=" text-xl cursor-pointer" />
        <p>Menu 1</p>
        <p>Menu 2</p>
        <p>Menu 3</p>
      </div>
    </nav>
  );
};

export default Navbar;

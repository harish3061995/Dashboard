import React from "react";
import a1 from "../assets/img/ava/1.png";
import a2 from "../assets/img/ava/2.png";
import a3 from "../assets/img/ava/3.png";

function Activity(props) {
  return (
    <div>
      <div className="flex justify-between w-full mt-10">
        <span className="font-semibold text-lg"> Hiring Candidates</span>
        <a
          href="javascript:void(0)"
          className="text-blue-500 text-base underline leading-6"
        >
          View All
        </a>
      </div>
      <div className="mt-5">
        <div className="flex flex-row mb-7">
          <div className="w-2/12">
            <div
              className=" flex flex-col py-2 items-center justify-center rounded-full rounded-[100%] overflow-hidden"
              style={{ borderRadius: "100%" }}
            >
              <img src={a1} alt="candi" className="h-auto w-auto" />
            </div>
          </div>
          <div className="w-10/12 pl-2">
            <div className="flex flex-col text-base">
              <p>
                John Doe{" "}
                <span className="text-blue-500">[Python Developer]</span>
              </p>
              <p className="text-base text-gray-500">Interview with Stella</p>
              <p className="text-sm text-gray-500">15 mins ago</p>
            </div>
          </div>
        </div>
        <div className="flex flex-row mb-7">
          <div className="w-2/12">
            <div
              className=" flex flex-col py-2 items-center justify-center rounded-full rounded-[100%] overflow-hidden"
              style={{ borderRadius: "100%" }}
            >
              <img src={a2} alt="candi" className="h-auto w-auto" />
            </div>
          </div>
          <div className="w-10/12 pl-2">
            <div className="flex flex-col text-base">
              <p>
                John Doe{" "}
                <span className="text-blue-500">[Python Developer]</span>
              </p>
              <p className="text-base text-gray-500">Interview with Stella</p>
              <p className="text-sm text-gray-500">15 mins ago</p>
            </div>
          </div>
        </div>
        <div className="flex flex-row mb-7">
          <div className="w-2/12">
            <div
              className=" flex flex-col py-2 items-center justify-center rounded-full rounded-[100%] overflow-hidden"
              style={{ borderRadius: "100%" }}
            >
              <img src={a3} alt="candi" className="h-auto w-auto" />
            </div>
          </div>
          <div className="w-10/12 pl-2">
            <div className="flex flex-col text-base">
              <p>
                John Doe{" "}
                <span className="text-blue-500">[Python Developer]</span>
              </p>
              <p className="text-base text-gray-500">Interview with Stella</p>
              <p className="text-sm text-gray-500">15 mins ago</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Activity;

import React from "react";

import dahsboard from "../assets/img/sideBar/dahsboard.png";
import icon1 from "../assets/img/sideBar/icon1.png";
import icon2 from "../assets/img/sideBar/icon2.png";
import icon3 from "../assets/img/sideBar/icon3.png";
import icon4 from "../assets/img/sideBar/icon4.png";
import icon5 from "../assets/img/sideBar/icon5.png";
import icon6 from "../assets/img/sideBar/icon6.png";
import icon7 from "../assets/img/sideBar/icon7.png";
import icon8 from "../assets/img/sideBar/icon8.png";
import { Link } from "react-router-dom";

function SideBar(props) {
  return (
    <div className="flex flex-col space items-center justify-start py-5  h-full   rounded-r-[40px] bg-white  shadow-[0px_0px_17px_4px_#e2e2e2]">
      <Link to="/">
        <div>
          <img src={dahsboard} alt="icon" className="w-auto py-4" />
        </div>
      </Link>
      <Link to="/about">
        <div>
          <img src={icon1} alt="icon" className="w-auto py-4" />
        </div>
      </Link>
      <Link to="/about">
        <div>
          <img src={icon2} alt="icon" className="w-auto py-4" />
        </div>{" "}
      </Link>
      <Link to="/about">
        <div>
          <img src={icon3} alt="icon" className="w-auto py-4" />
        </div>{" "}
      </Link>
      <Link to="/about">
        <div>
          <img src={icon4} alt="icon" className="w-auto py-4" />
        </div>{" "}
      </Link>
      <Link to="/about">
        <div>
          <img src={icon5} alt="icon" className="w-auto py-4" />
        </div>{" "}
      </Link>
      <Link to="/about">
        <div>
          <img src={icon6} alt="icon" className="w-auto py-4" />
        </div>{" "}
      </Link>
      <Link to="/about">
        <div>
          <img src={icon7} alt="icon" className="w-auto py-4" />
        </div>{" "}
      </Link>
      <Link to="/about">
        <div>
          <img src={icon8} alt="icon" className="w-auto py-4" />
        </div>{" "}
      </Link>
    </div>
  );
}

export default SideBar;

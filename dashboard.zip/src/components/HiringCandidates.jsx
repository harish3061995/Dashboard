import React from "react";
import c1 from "../assets/img/candi/1.png";
import c2 from "../assets/img/candi/2.png";
import c3 from "../assets/img/candi/3.png";
import c4 from "../assets/img/candi/4.png";
import c5 from "../assets/img/candi/5.png";

function HiringCandidates(props) {
  return (
    <div>
      <div className="flex justify-between w-full mt-10">
        <span className="font-semibold text-lg"> Hiring Candidates</span>
        <a
          href="javascript:void(0)"
          className="text-blue-500 text-base underline leading-6"
        >
          View All
        </a>
      </div>
      <div className="mt-5">
        <div className="flex flex-row mb-7">
          <div className="w-2/12">
            <div
              className=" flex flex-col py-2 items-center justify-center rounded-full rounded-[100%] overflow-hidden"
              style={{ borderRadius: "100%" }}
            >
              <img src={c1} alt="candi" className="h-auto w-auto" />
            </div>
          </div>
          <div className="w-8/12 pl-2">
            <div className="flex flex-col text-base">
              <p>John Doe</p>
              <p className="text-base text-gray-500">Senior Python Develpper</p>
              <p className="text-sm text-gray-500">Hired by: Stella</p>
            </div>
          </div>
          <div className="w-2/12">
            <button className="border-2 border-blue-600 text-[#0A66C2] rounded px-2 py-1">
              Details
            </button>
          </div>
        </div>
        <div className="flex flex-row mb-7">
          <div className="w-2/12">
            <div
              className=" flex flex-col py-2 items-center justify-center rounded-full rounded-[100%] overflow-hidden"
              style={{ borderRadius: "100%" }}
            >
              <img src={c2} alt="candi" className="h-auto w-auto" />
            </div>
          </div>
          <div className="w-8/12 pl-2">
            <div className="flex flex-col text-base">
              <p>John Doe</p>
              <p className="text-base text-gray-500">Senior Python Develpper</p>
              <p className="text-sm text-gray-500">Hired by: Stella</p>
            </div>
          </div>
          <div className="w-2/12">
            <button className="border-2 border-blue-600 text-[#0A66C2] rounded px-2 py-1">
              Details
            </button>
          </div>
        </div>
        <div className="flex flex-row mb-7">
          <div className="w-2/12">
            <div
              className=" flex flex-col py-2 items-center justify-center rounded-full rounded-[100%] overflow-hidden"
              style={{ borderRadius: "100%" }}
            >
              <img src={c3} alt="candi" className="h-auto w-auto" />
            </div>
          </div>
          <div className="w-8/12 pl-2">
            <div className="flex flex-col text-base">
              <p>John Doe</p>
              <p className="text-base text-gray-500">Senior Python Develpper</p>
              <p className="text-sm text-gray-500">Hired by: Stella</p>
            </div>
          </div>
          <div className="w-2/12">
            <button className="border-2 border-blue-600 text-[#0A66C2] rounded px-2 py-1">
              Details
            </button>
          </div>
        </div>
        <div className="flex flex-row mb-7">
          <div className="w-2/12">
            <div
              className=" flex flex-col py-2 items-center justify-center rounded-full rounded-[100%] overflow-hidden"
              style={{ borderRadius: "100%" }}
            >
              <img src={c4} alt="candi" className="h-auto w-auto" />
            </div>
          </div>
          <div className="w-8/12 pl-2">
            <div className="flex flex-col text-base">
              <p>John Doe</p>
              <p className="text-base text-gray-500">Senior Python Develpper</p>
              <p className="text-sm text-gray-500">Hired by: Stella</p>
            </div>
          </div>
          <div className="w-2/12">
            <button className="border-2 border-blue-600 text-[#0A66C2] rounded px-2 py-1">
              Details
            </button>
          </div>
        </div>
        <div className="flex flex-row mb-7">
          <div className="w-2/12">
            <div
              className=" flex flex-col py-2 items-center justify-center rounded-full rounded-[100%] overflow-hidden"
              style={{ borderRadius: "100%" }}
            >
              <img src={c5} alt="candi" className="h-auto w-auto" />
            </div>
          </div>
          <div className="w-8/12 pl-2">
            <div className="flex flex-col text-base">
              <p>John Doe</p>
              <p className="text-base text-gray-500">Senior Python Develpper</p>
              <p className="text-sm text-gray-500">Hired by: Stella</p>
            </div>
          </div>
          <div className="w-2/12">
            <button className="border-2 border-blue-600 text-[#0A66C2] rounded px-2 py-1">
              Details
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default HiringCandidates;

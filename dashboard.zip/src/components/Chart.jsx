// MixedChart.js
import React from "react";
import { Chart } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { useSelector } from "react-redux";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend
);

const MixedChart = () => {
  const barData = useSelector((state) => state.CommonSlice.barData);
  const linedata = useSelector((state) => state.CommonSlice.linedata);

  const data = {
    labels: [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ],
    datasets: [
      {
        type: "bar",
        label: "Sales",
        data: barData,
        backgroundColor: "rgba(39, 122, 204, 0.8)",
        borderColor: "rgba(39, 122, 204, 1)",
        borderWidth: 1,
      },
      {
        type: "line",
        label: "Revenue",
        data: linedata,
        backgroundColor: "rgba(0, 43, 85,0.8)",
        borderColor: "rgba(0, 43, 85 1)",
        borderWidth: 2,
        fill: false,
        tension: 0.4,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
        position: "top",
      },
      title: {
        display: false,
        text: "Monthly Sales and Revenue Data",
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  return (
    <div className="w-full h-64 px-7 py-5">
      <Chart type="bar" data={data} options={options} />
    </div>
  );
};

export default MixedChart;

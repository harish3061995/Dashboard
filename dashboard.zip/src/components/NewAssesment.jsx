import React from "react";
import Rectangle from "../assets/img/Rectangle.png";
import file from "../assets/img/file.png";
import smallgirl from "../assets/img/smallgirs.png";
import biggirl from "../assets/img/biggirl.png";

function NewAssesment(props) {
  return (
    <>
      <div className="w-5/12">
        <img
          src={file}
          alt="Rectangle"
          className="bg-white p-7 w-auto h-auto"
        />
        <h4 className="text-white text-4xl font-semibold my-7 px-1">0033</h4>
        <p className="text-white text-xl font-light">New Assessment's</p>
      </div>
      <div className="w-2/12 flex items-center">
        <img src={smallgirl} alt="smallgirl" className="w-auto h-auto" />
      </div>

      <div className="w-5/12 flex items-center flex-col">
        <img src={biggirl} alt="biggirl" className=" w-auto h-auto -mt-20" />
        <button className="bg-white text-gray-900 px-7 py-2 rounded-md">
          VIEW DETAILS
        </button>
      </div>
    </>
  );
}

export default NewAssesment;

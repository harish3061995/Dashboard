import React, { useState } from "react";
import {
  TETabs,
  TETabsContent,
  TETabsItem,
  TETabsPane,
} from "tw-elements-react";
import { CiCalendar, CiClock2 } from "react-icons/ci";
import py from "../assets/img/lang/py.png";
import an from "../assets/img/lang/ang.png";
import java from "../assets/img/lang/java 1.png";
import ux from "../assets/img/lang/ux.png";
import { FaSearch } from "react-icons/fa";
import { IoFilterOutline } from "react-icons/io5";
import { DiJavascript } from "react-icons/di";
import { GoArrowUp } from "react-icons/go";

function PostedJobs(props) {
  const [basicActive, setBasicActive] = useState("tab1");

  const handleBasicClick = (value) => {
    if (value === basicActive) {
      return;
    }
    setBasicActive(value);
  };

  return (
    <div className="flex flex-row space-x-5 ">
      <div className="w-full bg-white rounded-lg shadow-[4px_4px_25px_0px_#00000026]">
        <div className=" flex justify-between text-xl font-semibold  flex-col border-b-2 px-3 pt-3 mb-4 items-center">
          <div className="w-full flex justify-between">
            <div className="w-full">
              <span> Posted Jobs</span> &nbsp; &nbsp; &nbsp;
              <a
                href="javascript:void(0)"
                className="text-blue-500 text-base underline leading-6"
              >
                View All
              </a>
            </div>
            <div className="w-full flex flex-row justify-end">
              <div className="relative mr-4">
                <input
                  type="text"
                  placeholder="Search..."
                  className="pl-4 pr-10 max-w-52 py-2 rounded-sm drop-shadow-md focus:outline-none text-base"
                />
                <FaSearch className="absolute right-3 top-3 text-gray-400" />
              </div>
              <div className="flex relative rounded-sm shadow-md py-1 px-3 items-center justify-center">
                <IoFilterOutline className="text-blue-500" /> &nbsp;&nbsp;&nbsp;
                <span className="text-base">Filters</span>
              </div>
            </div>
          </div>
          <div className="w-full">
            <div className="">
              <TETabs className="!mb-0 ">
                <TETabsItem
                  onClick={() => handleBasicClick("tab1")}
                  active={basicActive === "tab1"}
                  className={`${
                    basicActive === "tab1"
                      ? "bg-blue-200 hover:bg-blue-200 text-black"
                      : ""
                  } px-5 py-1  border-0 rounded-b-nonetext-xl text-black`}
                >
                  Active Jobs
                </TETabsItem>
                <TETabsItem
                  onClick={() => handleBasicClick("tab2")}
                  active={basicActive === "tab2"}
                  className={`${
                    basicActive === "tab2"
                      ? "bg-blue-200 hover:bg-blue-200 text-black"
                      : ""
                  } px-5 py-1  border-0 rounded-b-nonetext-xl text-black`}
                >
                  Inactive Jobs
                </TETabsItem>
                <TETabsItem
                  onClick={() => handleBasicClick("tab3")}
                  active={basicActive === "tab3"}
                  className={`${
                    basicActive === "tab3"
                      ? "bg-blue-200 hover:bg-blue-200 text-black"
                      : ""
                  } px-5 py-1  border-0 rounded-b-nonetext-xl text-black`}
                >
                  Completed Jobs
                </TETabsItem>
              </TETabs>
            </div>
          </div>
        </div>
        <div className=" px-7 py-9 flex ">
          <TETabsContent className="w-full">
            <TETabsPane className="w-full" show={basicActive === "tab1"}>
              <div className="grid grid-cols-4  gap-4">
                <div className="shadow-lg p-1">
                  <div className="flex justify-between border-b-2 p-3">
                    <img src={py} alt="female" className=" w-auto" />
                    <span className="text-sm">Python Developers</span>
                    <span className="text-sm">#001</span>
                  </div>
                  <div className="flex flex-col items-center border-b-2">
                    <span className="mt-6 mb-4">Senior Developers</span>
                    <span className="bg-[#D9E4EF] p-7 text-blue-800">258</span>
                    <span className="mb-6 mt-4">Total Applicants</span>
                  </div>
                  <div className="flex justify-between p-3">
                    <span className="text-xs">
                      <span className="text-blue-500">
                        <GoArrowUp className="inline-block" /> 28%
                      </span>{" "}
                      vs Last month
                    </span>
                    <span className="text-xs">6 mins ago</span>
                  </div>
                </div>
                <div className="shadow-lg p-1">
                  <div className="flex justify-between border-b-2 p-3">
                    <img src={an} alt="Angular" className=" w-auto" />
                    <span className="text-sm">Angular Developers</span>
                    <span className="text-sm">#002</span>
                  </div>
                  <div className="flex flex-col items-center border-b-2">
                    <span className="mt-6 mb-4">Senior Developers</span>
                    <span className="bg-[#73A1FB] p-7 text-white">258</span>
                    <span className="mb-6 mt-4">Total Applicants</span>
                  </div>
                  <div className="flex justify-between p-3">
                    <span className="text-xs">
                      <span className="text-blue-500">
                        <GoArrowUp className="inline-block" /> 28%
                      </span>{" "}
                      vs Last month
                    </span>
                    <span className="text-xs">6 mins ago</span>
                  </div>
                </div>
                <div className="shadow-lg p-1">
                  <div className="flex justify-between border-b-2 p-3">
                    <img src={java} alt="java" className=" w-auto" />
                    <span className="text-sm">JAVA Developers</span>
                    <span className="text-sm">#003</span>
                  </div>
                  <div className="flex flex-col items-center border-b-2">
                    <span className="mt-6 mb-4">Senior Developers</span>
                    <span className="bg-[#2F73A0] p-7 text-white">258</span>
                    <span className="mb-6 mt-4">Total Applicants</span>
                  </div>
                  <div className="flex justify-between p-3">
                    <span className="text-xs">
                      <span className="text-blue-500">
                        <GoArrowUp className="inline-block" /> 28%
                      </span>{" "}
                      vs Last month
                    </span>
                    <span className="text-xs">6 mins ago</span>
                  </div>
                </div>
                <div className="shadow-lg p-1">
                  <div className="flex justify-between border-b-2 p-3">
                    <img src={ux} alt="female" className=" w-auto" />
                    <span className="text-sm">UX/UI Designers</span>
                    <span className="text-sm">#004</span>
                  </div>
                  <div className="flex flex-col items-center border-b-2">
                    <span className="mt-6 mb-4">Senior Developers</span>
                    <span className="bg-[#0A66C2] p-7 text-white">258</span>
                    <span className="mb-6 mt-4">Total Applicants</span>
                  </div>
                  <div className="flex justify-between p-3">
                    <span className="text-xs">
                      <span className="text-blue-500">
                        <GoArrowUp className="inline-block" /> 28%
                      </span>{" "}
                      vs Last month
                    </span>
                    <span className="text-xs">6 mins ago</span>
                  </div>
                </div>
              </div>
            </TETabsPane>
            <TETabsPane show={basicActive === "tab2"}>Tab 2 content</TETabsPane>
            <TETabsPane show={basicActive === "tab3"}>Tab 3 content</TETabsPane>
          </TETabsContent>
        </div>
      </div>
    </div>
  );
}

export default PostedJobs;

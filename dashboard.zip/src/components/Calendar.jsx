import React, { useState } from "react";
import { DateRange, DateRangePicker } from "react-date-range";
import { addDays } from "date-fns";
import "react-date-range/dist/styles.css"; // Main style file
import "react-date-range/dist/theme/default.css"; // Theme CSS file

// const customColors = {
//   selectionColor: "#4caf50", // Green for selection
// //   rangeColor: "#ff9800", // Orange for range
// //   hoverColor: "#f44336", // Red for hover
// };
const DateRangePickerComponent = () => {
  const [state, setState] = useState([
    {
      startDate: new Date(),
      endDate: addDays(new Date(), 7),
      key: "selection",
      //   color: customColors.selectionColor,
    },
  ]);
  return (
    <div className=" shadow-[4px_4px_25px_0px_#00000026]">
      <DateRange
        editableDateInputs={true}
        onChange={(item) => setState([item.selection])}
        moveRangeOnFirstSelection={false}
        ranges={state}
        direction="horizontal"
        //   rangeColors={[customColors.rangeColor]} // Applying custom range color
        //   preview={{ color: customColors.hoverColor }} // Applying custom hover color
      />
    </div>
  );
};

export default DateRangePickerComponent;

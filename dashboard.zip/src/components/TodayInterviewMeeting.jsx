import React from "react";
import { CiCalendar, CiClock2 } from "react-icons/ci";
import male from "../assets/img/male.png";
import female from "../assets/img/female.png";
import { useSelector } from "react-redux";
{
  /* <img src={female} alt="female" className=" ml-10 w-auto" /> */
}
function TodayInterviewMeeting(props) {
  return (
    <div className="flex flex-row space-x-5 ">
      <div className="w-full bg-white rounded-lg shadow-[4px_4px_25px_0px_#00000026]">
        <h5 className="text-xl font-semibold flex flex-row border-b-2 px-3 py-3 mb-4 items-center">
          <span> Today Interviews Meetings Info</span>
        </h5>
        <div className=" pl-7 py-9 pr-0 flex overflow-x-auto customScroll">
          <div>
            <div className="flex flex-row w-[650px] border border-2 border-gray-200 rounded mr-5">
              <div className="w-4/12 flex items-center justify-center flex-col border-r-2 border-gray-200">
                <div className="w-full flex flex-col items-center justify-center p-5 border-b-2 border-gray-200">
                  <img
                    src={male}
                    alt="male"
                    className=" h-auto w-auto rounded-full  my-2"
                  />

                  <h2 className="text-lg text-gray-800">John Smith</h2>
                  <p className="text-sm text-gray-800">
                    Senior Python Developer
                  </p>
                </div>
                <div className="flex w-full text-sm text-blue-500">
                  <div className="flex flex-col  w-full items-center  border-r-2 border-gray-200 px-2 py-2">
                    <span>
                      <CiCalendar className="text-2xl" />
                    </span>
                    <span className="text-xs mt-2">19th Feb 2024</span>
                  </div>
                  <div className="flex flex-col  w-full items-center px-2 py-2">
                    <span>
                      <CiClock2 className="text-2xl" />
                    </span>
                    <span className="text-xs mt-2">10.30 A.M</span>
                  </div>
                </div>
              </div>
              <div className="w-8/12">
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      1st Level: &nbsp;&nbsp;&nbsp;&nbsp;7/10
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Stella
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      2st Level: &nbsp;&nbsp;&nbsp;&nbsp;6/10
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Smith
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      3rd Level: &nbsp;&nbsp;&nbsp;&nbsp;Waiting
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Stephan
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      Meet Via: &nbsp;&nbsp;&nbsp;&nbsp;G-meet
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;johanson
                    </p>
                  </div>
                </div>
                <div className="h-full max-h-24 flex items-center justify-center">
                  <button className="border border-2 border-blue-500 text-blue-500 rounded px-8 py-2 mr-5">
                    Reschedule Meeting
                  </button>
                  <button className="border border-2 border-blue-500 text-white bg-blue-500 rounded px-8 py-2">
                    Join Meeting
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div>
            <div className="flex flex-row  w-[650px] border border-2 border-gray-200 rounded mr-5">
              <div className="w-4/12 flex items-center justify-center flex-col border-r-2 border-gray-200">
                <div className="w-full flex flex-col items-center justify-center p-5 border-b-2 border-gray-200">
                  <img
                    src={female}
                    alt="male"
                    className=" h-auto w-auto rounded-full  my-2"
                  />

                  <h2 className="text-lg text-gray-800">Maria</h2>
                  <p className="text-sm text-gray-800">
                    Senior Python Developer
                  </p>
                </div>
                <div className="flex w-full text-sm text-blue-500">
                  <div className="flex flex-col  w-full items-center  border-r-2 border-gray-200 px-2 py-2">
                    <span>
                      <CiCalendar className="text-2xl" />
                    </span>
                    <span className="text-xs mt-2">19th Feb 2024</span>
                  </div>
                  <div className="flex flex-col  w-full items-center px-2 py-2">
                    <span>
                      <CiClock2 className="text-2xl" />
                    </span>
                    <span className="text-xs mt-2">10.30 A.M</span>
                  </div>
                </div>
              </div>
              <div className="w-8/12">
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      1st Level: &nbsp;&nbsp;&nbsp;&nbsp;7/10
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Stella
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      2st Level: &nbsp;&nbsp;&nbsp;&nbsp;6/10
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Smith
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      3rd Level: &nbsp;&nbsp;&nbsp;&nbsp;Waiting
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Stephan
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      Meet Via: &nbsp;&nbsp;&nbsp;&nbsp;G-meet
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;johanson
                    </p>
                  </div>
                </div>
                <div className="h-full max-h-24 flex items-center justify-center">
                  <button className="border border-2 border-blue-500 text-blue-500 rounded px-8 py-2 mr-5">
                    Reschedule Meeting
                  </button>
                  <button className="border border-2 border-blue-500 text-white bg-blue-500 rounded px-8 py-2">
                    Join Meeting
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div>
            <div className="flex flex-row w-[650px] border border-2 border-gray-200 rounded mr-5">
              <div className="w-4/12 flex items-center justify-center flex-col border-r-2 border-gray-200">
                <div className="w-full flex flex-col items-center justify-center p-5 border-b-2 border-gray-200">
                  <img
                    src={male}
                    alt="male"
                    className=" h-auto w-auto rounded-full  my-2"
                  />

                  <h2 className="text-lg text-gray-800">John Smith</h2>
                  <p className="text-sm text-gray-800">
                    Senior Python Developer
                  </p>
                </div>
                <div className="flex w-full text-sm text-blue-500">
                  <div className="flex flex-col  w-full items-center  border-r-2 border-gray-200 px-2 py-2">
                    <span>
                      <CiCalendar className="text-2xl" />
                    </span>
                    <span className="text-xs mt-2">19th Feb 2024</span>
                  </div>
                  <div className="flex flex-col  w-full items-center px-2 py-2">
                    <span>
                      <CiClock2 className="text-2xl" />
                    </span>
                    <span className="text-xs mt-2">10.30 A.M</span>
                  </div>
                </div>
              </div>
              <div className="w-8/12">
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      1st Level: &nbsp;&nbsp;&nbsp;&nbsp;7/10
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Stella
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      2st Level: &nbsp;&nbsp;&nbsp;&nbsp;6/10
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Smith
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      3rd Level: &nbsp;&nbsp;&nbsp;&nbsp;Waiting
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Stephan
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      Meet Via: &nbsp;&nbsp;&nbsp;&nbsp;G-meet
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;johanson
                    </p>
                  </div>
                </div>
                <div className="h-full max-h-24 flex items-center justify-center">
                  <button className="border border-2 border-blue-500 text-blue-500 rounded px-8 py-2 mr-5">
                    Reschedule Meeting
                  </button>
                  <button className="border border-2 border-blue-500 text-white bg-blue-500 rounded px-8 py-2">
                    Join Meeting
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div>
            <div className="flex flex-row  w-[650px] border border-2 border-gray-200 rounded mr-5">
              <div className="w-4/12 flex items-center justify-center flex-col border-r-2 border-gray-200">
                <div className="w-full flex flex-col items-center justify-center p-5 border-b-2 border-gray-200">
                  <img
                    src={female}
                    alt="male"
                    className=" h-auto w-auto rounded-full  my-2"
                  />

                  <h2 className="text-lg text-gray-800">Maria</h2>
                  <p className="text-sm text-gray-800">
                    Senior Python Developer
                  </p>
                </div>
                <div className="flex w-full text-sm text-blue-500">
                  <div className="flex flex-col  w-full items-center  border-r-2 border-gray-200 px-2 py-2">
                    <span>
                      <CiCalendar className="text-2xl" />
                    </span>
                    <span className="text-xs mt-2">19th Feb 2024</span>
                  </div>
                  <div className="flex flex-col  w-full items-center px-2 py-2">
                    <span>
                      <CiClock2 className="text-2xl" />
                    </span>
                    <span className="text-xs mt-2">10.30 A.M</span>
                  </div>
                </div>
              </div>
              <div className="w-8/12">
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      1st Level: &nbsp;&nbsp;&nbsp;&nbsp;7/10
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Stella
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      2st Level: &nbsp;&nbsp;&nbsp;&nbsp;6/10
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Smith
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      3rd Level: &nbsp;&nbsp;&nbsp;&nbsp;Waiting
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Stephan
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      Meet Via: &nbsp;&nbsp;&nbsp;&nbsp;G-meet
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;johanson
                    </p>
                  </div>
                </div>
                <div className="h-full max-h-24 flex items-center justify-center">
                  <button className="border border-2 border-blue-500 text-blue-500 rounded px-8 py-2 mr-5">
                    Reschedule Meeting
                  </button>
                  <button className="border border-2 border-blue-500 text-white bg-blue-500 rounded px-8 py-2">
                    Join Meeting
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div>
            <div className="flex flex-row w-[650px] border border-2 border-gray-200 rounded mr-5">
              <div className="w-4/12 flex items-center justify-center flex-col border-r-2 border-gray-200">
                <div className="w-full flex flex-col items-center justify-center p-5 border-b-2 border-gray-200">
                  <img
                    src={male}
                    alt="male"
                    className=" h-auto w-auto rounded-full  my-2"
                  />

                  <h2 className="text-lg text-gray-800">John Smith</h2>
                  <p className="text-sm text-gray-800">
                    Senior Python Developer
                  </p>
                </div>
                <div className="flex w-full text-sm text-blue-500">
                  <div className="flex flex-col  w-full items-center  border-r-2 border-gray-200 px-2 py-2">
                    <span>
                      <CiCalendar className="text-2xl" />
                    </span>
                    <span className="text-xs mt-2">19th Feb 2024</span>
                  </div>
                  <div className="flex flex-col  w-full items-center px-2 py-2">
                    <span>
                      <CiClock2 className="text-2xl" />
                    </span>
                    <span className="text-xs mt-2">10.30 A.M</span>
                  </div>
                </div>
              </div>
              <div className="w-8/12">
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      1st Level: &nbsp;&nbsp;&nbsp;&nbsp;7/10
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Stella
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      2st Level: &nbsp;&nbsp;&nbsp;&nbsp;6/10
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Smith
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      3rd Level: &nbsp;&nbsp;&nbsp;&nbsp;Waiting
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Stephan
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      Meet Via: &nbsp;&nbsp;&nbsp;&nbsp;G-meet
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;johanson
                    </p>
                  </div>
                </div>
                <div className="h-full max-h-24 flex items-center justify-center">
                  <button className="border border-2 border-blue-500 text-blue-500 rounded px-8 py-2 mr-5">
                    Reschedule Meeting
                  </button>
                  <button className="border border-2 border-blue-500 text-white bg-blue-500 rounded px-8 py-2">
                    Join Meeting
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div>
            <div className="flex flex-row  w-[650px] border border-2 border-gray-200 rounded mr-5">
              <div className="w-4/12 flex items-center justify-center flex-col border-r-2 border-gray-200">
                <div className="w-full flex flex-col items-center justify-center p-5 border-b-2 border-gray-200">
                  <img
                    src={female}
                    alt="male"
                    className=" h-auto w-auto rounded-full  my-2"
                  />

                  <h2 className="text-lg text-gray-800">Maria</h2>
                  <p className="text-sm text-gray-800">
                    Senior Python Developer
                  </p>
                </div>
                <div className="flex w-full text-sm text-blue-500">
                  <div className="flex flex-col  w-full items-center  border-r-2 border-gray-200 px-2 py-2">
                    <span>
                      <CiCalendar className="text-2xl" />
                    </span>
                    <span className="text-xs mt-2">19th Feb 2024</span>
                  </div>
                  <div className="flex flex-col  w-full items-center px-2 py-2">
                    <span>
                      <CiClock2 className="text-2xl" />
                    </span>
                    <span className="text-xs mt-2">10.30 A.M</span>
                  </div>
                </div>
              </div>
              <div className="w-8/12">
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      1st Level: &nbsp;&nbsp;&nbsp;&nbsp;7/10
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Stella
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      2st Level: &nbsp;&nbsp;&nbsp;&nbsp;6/10
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Smith
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      3rd Level: &nbsp;&nbsp;&nbsp;&nbsp;Waiting
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Stephan
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      Meet Via: &nbsp;&nbsp;&nbsp;&nbsp;G-meet
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;johanson
                    </p>
                  </div>
                </div>
                <div className="h-full max-h-24 flex items-center justify-center">
                  <button className="border border-2 border-blue-500 text-blue-500 rounded px-8 py-2 mr-5">
                    Reschedule Meeting
                  </button>
                  <button className="border border-2 border-blue-500 text-white bg-blue-500 rounded px-8 py-2">
                    Join Meeting
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div>
            <div className="flex flex-row w-[650px] border border-2 border-gray-200 rounded mr-5">
              <div className="w-4/12 flex items-center justify-center flex-col border-r-2 border-gray-200">
                <div className="w-full flex flex-col items-center justify-center p-5 border-b-2 border-gray-200">
                  <img
                    src={male}
                    alt="male"
                    className=" h-auto w-auto rounded-full  my-2"
                  />

                  <h2 className="text-lg text-gray-800">John Smith</h2>
                  <p className="text-sm text-gray-800">
                    Senior Python Developer
                  </p>
                </div>
                <div className="flex w-full text-sm text-blue-500">
                  <div className="flex flex-col  w-full items-center  border-r-2 border-gray-200 px-2 py-2">
                    <span>
                      <CiCalendar className="text-2xl" />
                    </span>
                    <span className="text-xs mt-2">19th Feb 2024</span>
                  </div>
                  <div className="flex flex-col  w-full items-center px-2 py-2">
                    <span>
                      <CiClock2 className="text-2xl" />
                    </span>
                    <span className="text-xs mt-2">10.30 A.M</span>
                  </div>
                </div>
              </div>
              <div className="w-8/12">
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      1st Level: &nbsp;&nbsp;&nbsp;&nbsp;7/10
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Stella
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      2st Level: &nbsp;&nbsp;&nbsp;&nbsp;6/10
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Smith
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      3rd Level: &nbsp;&nbsp;&nbsp;&nbsp;Waiting
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Stephan
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      Meet Via: &nbsp;&nbsp;&nbsp;&nbsp;G-meet
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;johanson
                    </p>
                  </div>
                </div>
                <div className="h-full max-h-24 flex items-center justify-center">
                  <button className="border border-2 border-blue-500 text-blue-500 rounded px-8 py-2 mr-5">
                    Reschedule Meeting
                  </button>
                  <button className="border border-2 border-blue-500 text-white bg-blue-500 rounded px-8 py-2">
                    Join Meeting
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div>
            <div className="flex flex-row  w-[650px] border border-2 border-gray-200 rounded mr-5">
              <div className="w-4/12 flex items-center justify-center flex-col border-r-2 border-gray-200">
                <div className="w-full flex flex-col items-center justify-center p-5 border-b-2 border-gray-200">
                  <img
                    src={female}
                    alt="male"
                    className=" h-auto w-auto rounded-full  my-2"
                  />

                  <h2 className="text-lg text-gray-800">Maria</h2>
                  <p className="text-sm text-gray-800">
                    Senior Python Developer
                  </p>
                </div>
                <div className="flex w-full text-sm text-blue-500">
                  <div className="flex flex-col  w-full items-center  border-r-2 border-gray-200 px-2 py-2">
                    <span>
                      <CiCalendar className="text-2xl" />
                    </span>
                    <span className="text-xs mt-2">19th Feb 2024</span>
                  </div>
                  <div className="flex flex-col  w-full items-center px-2 py-2">
                    <span>
                      <CiClock2 className="text-2xl" />
                    </span>
                    <span className="text-xs mt-2">10.30 A.M</span>
                  </div>
                </div>
              </div>
              <div className="w-8/12">
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      1st Level: &nbsp;&nbsp;&nbsp;&nbsp;7/10
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Stella
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      2st Level: &nbsp;&nbsp;&nbsp;&nbsp;6/10
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Smith
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      3rd Level: &nbsp;&nbsp;&nbsp;&nbsp;Waiting
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;Stephan
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 border-b-2 border-gray-20 w-full">
                  <div className="p-4 pb-2 border-r-2 border-gray-200">
                    <p className="text-sm">
                      Meet Via: &nbsp;&nbsp;&nbsp;&nbsp;G-meet
                    </p>
                  </div>
                  <div className="p-4 pb-2 ">
                    <p className="text-sm">
                      Interviewer: &nbsp;&nbsp;&nbsp;&nbsp;johanson
                    </p>
                  </div>
                </div>
                <div className="h-full max-h-24 flex items-center justify-center">
                  <button className="border border-2 border-blue-500 text-blue-500 rounded px-8 py-2 mr-5">
                    Reschedule Meeting
                  </button>
                  <button className="border border-2 border-blue-500 text-white bg-blue-500 rounded px-8 py-2">
                    Join Meeting
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default TodayInterviewMeeting;

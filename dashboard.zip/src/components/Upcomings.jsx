import React from "react";

function Upcomings(props) {
  return (
    <div>
      <div className="flex justify-between w-full mt-10">
        <span className="font-semibold text-lg"> Upcomings</span>
        <a
          href="javascript:void(0)"
          className="text-blue-500 text-base underline leading-6"
        >
          View All
        </a>
      </div>
      <div className="mt-5">
        <div className="flex flex-row mb-7">
          <div className="w-2/12">
            <div className="bg-blue-300 text-blue-700 flex flex-col py-2 items-center justify-center rounded text-sm">
              <span className="block mb-1">07</span>
              <span className="block ">Feb</span>
            </div>
          </div>
          <div className="w-8/12 pl-2">
            <div className="flex flex-col text-base">
              <p>Interview with Designer</p>
              <p className="text-base text-gray-500">
                Created by <span className="text-blue-400">Stella</span>
              </p>
              <p className="text-sm text-gray-500">10 A.M to 11 A.M</p>
            </div>
          </div>
          <div className="w-2/12">
            <button className="bg-[#0A66C2] text-white rounded px-2 py-1">
              Details
            </button>
          </div>
        </div>
        <div className="flex flex-row mb-7">
          <div className="w-2/12">
            <div className="bg-gray-400 text-gray-800 flex flex-col py-2 items-center justify-center rounded text-sm">
              <span className="block mb-1">07</span>
              <span className="block ">Feb</span>
            </div>
          </div>
          <div className="w-8/12 pl-2">
            <div className="flex flex-col text-base">
              <p>Interview with PMO</p>
              <p className="text-base text-gray-500">
                Created by <span className="text-blue-400">Stella</span>
              </p>
              <p className="text-sm text-gray-500">10 A.M to 11 A.M</p>
            </div>
          </div>
          <div className="w-2/12">
            <button className="bg-[#0A66C2] text-white rounded px-2 py-1">
              Details
            </button>
          </div>
        </div>
        <div className="flex flex-row mb-7">
          <div className="w-2/12">
            <div className="bg-gray-200 text-gray-800 flex flex-col py-2 items-center justify-center rounded text-sm">
              <span className="block mb-1">07</span>
              <span className="block ">Feb</span>
            </div>
          </div>
          <div className="w-8/12 pl-2">
            <div className="flex flex-col text-base">
              <p>Interview with Net. Admin</p>
              <p className="text-base text-gray-500">
                Created by <span className="text-blue-400">Stella</span>
              </p>
              <p className="text-sm text-gray-500">10 A.M to 11 A.M</p>
            </div>
          </div>
          <div className="w-2/12">
            <button className="bg-[#0A66C2] text-white rounded px-2 py-1">
              Details
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Upcomings;
